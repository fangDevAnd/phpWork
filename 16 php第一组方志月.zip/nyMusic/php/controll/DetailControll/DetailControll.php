<?php


/**
 * Class DetailControll
 *
 * 实现得到是详情界面的实现
 */
class DetailControll
{

    public function getAllData()
    {

    }

}